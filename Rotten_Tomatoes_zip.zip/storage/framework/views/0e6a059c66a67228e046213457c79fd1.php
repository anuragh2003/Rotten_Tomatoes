<?php echo $__env->make('header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="container mx-auto px-6 py-8">
    <h2 class="text-3xl font-bold mb-6 text-gray-800">🎬 All Movies</h2>

    <?php if($movies->isEmpty()): ?>
        <p class="text-gray-600">No movies available.</p>
    <?php else: ?>
        <div class="grid gap-8 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
            <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e(auth()->check() ? route('movies.show', $movie->id) : route('login')); ?>" class="block">
        <div class="bg-white shadow-lg rounded-xl overflow-hidden transform transition hover:scale-105 hover:shadow-2xl">
            <img src="<?php echo e(asset('storage/' . $movie->poster)); ?>" 
                 alt="<?php echo e($movie->title); ?>" 
                 class="w-full h-56 object-cover">
            <div class="p-4">
                <h3 class="text-lg font-semibold text-gray-900 truncate"><?php echo e($movie->title); ?></h3>
                <p class="text-sm text-gray-600 mt-1"><?php echo e($movie->genres); ?></p>
            </div>
        </div>
    </a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
</div>

<?php echo $__env->make('footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH C:\Users\J.ANURAGH\Rotten_Tomatoes\resources\views/movies.blade.php ENDPATH**/ ?>