<?php echo $__env->make('header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="container mx-auto px-6 py-8">
    <h1 class="text-3xl font-bold text-gray-900 mb-8">⭐ Top Rated</h1>

    <!-- Movies -->
    <h2 class="text-2xl font-semibold text-gray-800 mb-4">🎬 Movies</h2>
    <div class="grid gap-6 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 mb-12">
        <?php $__empty_1 = true; $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <a href="<?php echo e(auth()->check() ? route('movies.show', $movie->id) : route('login')); ?>" class="block">
                <div class="bg-white shadow-lg rounded-lg overflow-hidden hover:scale-105 transition transform">
                    <img src="<?php echo e(asset('storage/' . $movie->poster)); ?>" class="w-full h-48 object-cover" alt="<?php echo e($movie->title); ?>">
                    <div class="p-4">
                        <h3 class="font-semibold text-lg text-gray-900"><?php echo e($movie->title); ?></h3>
                        <p class="text-yellow-500">⭐ <?php echo e(number_format($movie->reviews_avg_rating, 1)); ?>/5</p>
                    </div>
                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-gray-500">No rated movies yet.</p>
        <?php endif; ?>
    </div>

    <!-- TV Shows -->
    <h2 class="text-2xl font-semibold text-gray-800 mb-4">📺 TV Shows</h2>
    <div class="grid gap-6 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
        <?php $__empty_1 = true; $__currentLoopData = $tvshows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $show): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <a href="<?php echo e(auth()->check() ? route('tvshows.show', $show->id) : route('login')); ?>" class="block">
                <div class="bg-white shadow-lg rounded-lg overflow-hidden hover:scale-105 transition transform">
                    <img src="<?php echo e(asset('storage/' . $show->poster)); ?>" class="w-full h-48 object-cover" alt="<?php echo e($show->title); ?>">
                    <div class="p-4">
                        <h3 class="font-semibold text-lg text-gray-900"><?php echo e($show->title); ?></h3>
                        <p class="text-yellow-500">⭐ <?php echo e(number_format($show->reviews_avg_rating, 1)); ?>/5</p>
                    </div>
                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-gray-500">No rated shows yet.</p>
        <?php endif; ?>
    </div>
</div>

<?php echo $__env->make('footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH C:\Users\J.ANURAGH\Rotten_Tomatoes\resources\views/top-rated.blade.php ENDPATH**/ ?>