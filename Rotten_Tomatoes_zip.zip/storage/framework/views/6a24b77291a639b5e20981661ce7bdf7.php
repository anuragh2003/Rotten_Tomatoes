<?php echo $__env->make('header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="container mx-auto px-6 py-8">
    <!-- Movie Trailer -->
    <div class="aspect-w-16 aspect-h-9 mb-6">
        <iframe 
            src="<?php echo e($movie->trailer_url); ?>" 
            title="<?php echo e($movie->title); ?> Trailer" 
            class="w-full h-[500px] rounded-lg shadow-lg"
            frameborder="0" 
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
            allowfullscreen>
        </iframe>
    </div>

    <!-- Movie Info -->
    <div class="bg-white p-6 rounded-lg shadow-md mb-8">
        <h1 class="text-3xl font-bold text-gray-900 mb-4"><?php echo e($movie->title); ?></h1>
        <p class="text-gray-700"><strong>Age Rating:</strong> <?php echo e($movie->age_rating); ?></p>
        <p class="text-gray-700"><strong>Duration:</strong> <?php echo e($movie->duration); ?></p>
        <p class="text-gray-700"><strong>Genres:</strong> <?php echo e($movie->genres); ?></p>
    </div>

    <!-- Reviews Section -->
    <h2 class="text-2xl font-semibold text-gray-800 mb-4">Audience Reviews</h2>

    <!-- Review Form -->
    <?php if(auth()->guard()->check()): ?>
        <form action="<?php echo e(route('reviews.store', $movie->id)); ?>" method="POST" class="bg-white p-6 rounded-xl shadow-md mb-8">
            <?php echo csrf_field(); ?>

            <!-- Star Rating -->
            <label class="block text-gray-700 font-medium mb-2">Your Rating</label>
            <div class="flex items-center space-x-1 mb-4">
                <?php for($i = 1; $i <= 5; $i++): ?>
                    <input type="radio" id="star<?php echo e($i); ?>" name="rating" value="<?php echo e($i); ?>" class="hidden peer/star<?php echo e($i); ?>">
                    <label for="star<?php echo e($i); ?>" class="cursor-pointer text-3xl text-gray-400 peer-checked/star<?php echo e($i); ?>:text-yellow-400 hover:text-yellow-300">
                        ★
                    </label>
                <?php endfor; ?>
            </div>

            <!-- Fresh/Rotten -->
            <label class="block text-gray-700 font-medium mb-2">Fresh or Rotten?</label>
            <select name="status" class="w-full border rounded-md p-2 mb-4">
                <option value="Fresh">Fresh 🍅</option>
                <option value="Rotten">Rotten 🤢</option>
            </select>

            <!-- Review Body -->
            <label class="block text-gray-700 font-medium mb-2">Review Text</label>
            <textarea name="body" rows="3" class="w-full border rounded-md p-2 mb-4"></textarea>

            <button type="submit" class="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition">
                Submit Review
            </button>
        </form>
    <?php else: ?>
        <p class="text-red-500 mb-6">⚠️ You must <a href="<?php echo e(route('login')); ?>" class="underline">log in</a> to leave a review.</p>
    <?php endif; ?>

    <!-- Reviews List -->
    <div class="space-y-6">
        <?php $__empty_1 = true; $__currentLoopData = $movie->reviews()->where('approved', true)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="bg-gray-50 p-4 rounded-lg shadow">
                <strong class="text-lg text-gray-800"><?php echo e($review->user->name); ?></strong>
                <div class="flex items-center space-x-2 text-yellow-400">
                    <?php for($i = 1; $i <= 5; $i++): ?>
                        <span class="<?php echo e($i <= $review->rating ? 'text-yellow-400' : 'text-gray-300'); ?>">★</span>
                    <?php endfor; ?>
                    <span class="ml-2 text-sm text-gray-600"><?php echo e($review->status); ?></span>
                </div>
                <p class="text-gray-700 mt-2"><?php echo e($review->body); ?></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-gray-500">No reviews yet. Be the first one to review!</p>
        <?php endif; ?>
    </div>
</div>

<?php echo $__env->make('footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH C:\Users\J.ANURAGH\Rotten_Tomatoes\resources\views/movies/show.blade.php ENDPATH**/ ?>